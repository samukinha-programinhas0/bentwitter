import express from 'express';
import bcrypt from 'bcrypt';
import { User } from '../modelos/usuarios.js';

const router = express.Router();

router.post('/usuarios', async (req, res) => {}