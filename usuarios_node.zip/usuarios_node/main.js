const express = require("express");
const { User, sequelize } = require("./src/modelos/usuarios");

const app = express();
const port = 3000;

app.use(express.json());

sequelize.sync()
  .then(() => console.log("Banco de dados sincronizado"))
  .catch((error) => console.error("Erro ao sincronizar banco de dados:", error));

  app.post("/usuarios", async (req, res) => {
    try {
      const { nome, email, senha } = req.body;
      const novoUsuario = await User.create({ nome, email, senha });

    res.status(201).json({
      message: "Usuário criado com sucesso",
      usuario: {
        id: novoUsuario.id,
        nome: novoUsuario.nome,
        email: novoUsuario.email
      }
    });
  } catch (err) {
    res.status(400).json({ error: "Erro ao criar usuário", detalhes: err.message });
  }
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
  });